require('./dist/ng-sortable');
module.exports = 'as.sortable';
